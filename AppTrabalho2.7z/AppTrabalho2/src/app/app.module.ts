import { BrowserModule } from '@angular/platform-browser';
//// import { NgModule, LOCALE_ID } from '@angular/core';
import { NgModule} from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateComponent } from './categoria/create/create.component';
import { IndexComponent } from './categoria/index/index.component';
import { TopoComponent } from './topo/topo.component';
import { appRoutes } from './app.routes';

import { HttpErrorHandlerService } from './http-error-handler.service';
import { MessageService } from './message.service';
import { CategoriaService } from './categoria/categoria.service';
import { ProdutoService } from './produto/produto.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { IndexListProdutoComponent } from './produto/index-list-produto/index-list-produto.component';
import { HomeComponent } from './home/home.component';
import { OfertaComponent } from './oferta/oferta.component';
import { OrdemCompraComponent } from './ordem-compra/ordem-compra.component';
import { CarrinhoService } from './carrinho.service';
import { OrdemCompraService } from './ordem-compra.service';
import { CepService } from './cep.service';
import { CreateProdutoComponent } from './produto/create-produto/create-produto.component';
import { OrdemCompraSucessoComponent } from './ordem-compra-sucesso/ordem-compra-sucesso.component';
import { RodapeComponent } from './rodape/rodape.component';
import { AlertComponent } from './alert/alert.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

import { ReactiveFormsModule } from '@angular/forms';
import { fakeBackendProvider } from '../app/_helpers/fake-backend';
import { JwtInterceptor } from '../app/_helpers/jwt.interceptor';
import { ErrorInterceptor } from '../app/_helpers/error.interceptor';
import { AuthenticationService } from './authentication.service';
import { UserService } from './user.service';
import { UsuarioComponent } from './usuario/usuario.component';
/// { provide: LOCALE_ID, useValue : 'pt-Br' }

@NgModule({
  declarations: [
    AppComponent,
    CreateComponent,
    IndexComponent,
    TopoComponent,
    IndexListProdutoComponent,
    HomeComponent,
    OfertaComponent,
    OrdemCompraComponent,
    CreateProdutoComponent,
    OrdemCompraSucessoComponent,
    RodapeComponent,
    AlertComponent,
    LoginComponent,
    RegisterComponent,
    UsuarioComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
    BrowserAnimationsModule,
    ReactiveFormsModule
  ],
  providers: [
               HttpErrorHandlerService,
               MessageService,
               CategoriaService,
               ProdutoService,
               CarrinhoService,
               OrdemCompraService,
               CepService,
               { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
               { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
               fakeBackendProvider,
               AuthenticationService,
               UserService
            ],
  bootstrap: [AppComponent]
})
export class AppModule { }
