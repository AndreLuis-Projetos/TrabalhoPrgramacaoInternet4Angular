import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CategoriaService } from 'src/app/categoria/categoria.service';
import { Categoria } from 'src/app/shared/categoria.model';
import { ProdutoService } from '../produto.service';
import { Produto } from 'src/app/shared/produto.model';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-create-produto',
  templateUrl: './create-produto.component.html',
  styleUrls: ['./create-produto.component.css']
})
export class CreateProdutoComponent implements OnInit {

  @ViewChild('formulario', {static: false}) public formulario: NgForm;
  public categorias : Categoria[] = [];
  public produto: Produto;
  public id: number;

  constructor(private categoriaService: CategoriaService, 
              private produtoService: ProdutoService,
              private router: Router,
              private rota: ActivatedRoute
              ) { }

  ngOnInit() {
     
    //selct da categoria no cadastro de produto
      this.categoriaService.getCategorias()
          .subscribe( categoria =>{ this.categorias = categoria });

      this.id = this.rota.snapshot.params['id'];

    if(this.id){
      this.produtoService.produtoPorId(this.id).subscribe(res =>{
        this.formulario.setValue({
            nome: res.nome,
            descricao: res.descricao,
            preco: res.preco,
            quantidade: res.quantidade,
            dataValidade: res.dataValidade,
            marca: res.marca,
            unidade: res.unidade,
            peso: res.peso,
            url: res.imagens,
            desconto: res.desconto,
            categoria: res.categoria
        });
      }, err=>{
        console.log("error: "+ err);
      }
      ); 

    }
  }

  public salvar(): void {
     
    let produto = new Produto();

       produto.nome = this.formulario.value.nome;
       produto.descricao = this.formulario.value.descricao;
       produto.preco = this.formulario.value.preco;
       produto.quantidade = this.formulario.value.quantidade;
       produto.dataValidade = this.formulario.value.dataValidade;
       produto.marca = this.formulario.value.marca;
       produto.unidade = this.formulario.value.unidade;
       produto.peso = this.formulario.value.peso;
       produto.imagens = this.formulario.value.url;
       produto.categoria = this.formulario.value.categoria;
       produto.desconto = this.formulario.value.desconto;

    if(this.id)
    {
      this.produtoService.updateProduto(this.id, produto).subscribe(
        res=>{console.log(this.produto)
        },err =>{console.error("error"+ err)}
        );
    }
    else{     
      this.produtoService.adicionarProduto(produto).subscribe(teste => console.log(teste));
    }

    this.router.navigate(['produto']);   
  }
}