import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, retry, map, delay } from 'rxjs/operators';
import { HttpErrorHandlerService, HandleError } from '../http-error-handler.service';
import { Produto} from '../shared/produto.model';

const httpOptions = {
  headers: new HttpHeaders(
    {'Content-Type':  'application/json', Authorization: 'my-auth-token'})
};

@Injectable({
  providedIn: 'root'
})
export class ProdutoService {
  private handleError: HandleError;
  private apiUrl = 'http://localhost:5000/produto';

  constructor(
    private http: HttpClient,
    httpErrorHandler: HttpErrorHandlerService) {
    this.handleError = httpErrorHandler.createHandleError('HeroesService');
  }

  public getProdutos(): Observable<Produto[]> {
    return this.http.get<Produto[]>(this.apiUrl)
       .pipe(
         delay(2000),
          catchError(this.handleError('getProdutos', []))
       );
  }

  public deletarProduto(id: number) {
    const url = `${this.apiUrl}/${id}`;
    return this.http.delete(url, httpOptions)
        .pipe(
          catchError(this.handleError('deletarProduto'))
        );
  }

  public getProdutosPorId(id: number): Promise<Produto> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.get<Produto>(url, httpOptions)
        .toPromise()
        .then((resposta: any) => resposta[0]);
  }

  public adicionarProduto(produto: Produto): Observable<Produto> {
    return this.http.post<Produto>(this.apiUrl, JSON.stringify(produto), httpOptions)
      .pipe( catchError(this.handleError('adicionarProduto', produto)));

  }

  public updateProduto(id: number, produto: Produto): Observable<any> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.put(url, produto, httpOptions).pipe(
      catchError(this.handleError('updateCategoria'))
    );
  }

  public updateProdutoQuantidade(id: number, produto: Produto): Observable<any> {
    console.log('alterando a quantidade');

    const url = `${this.apiUrl + '/quantidade'}/${id}`;
    console.log(url);
    return this.http.put(url, produto, httpOptions).pipe(
      catchError(this.handleError('updateProdutoQuantidade'))
    );
  }

  public produtoPorId(id: number): Observable<Produto> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.get<Produto>(url).pipe(
      tap(_ => console.log(`fetched getCategoriaPorId id=${id}`)),
      catchError(this.handleError<Produto>('getCategorias id=${id}'))
    );
  }

  public pesquisarPorProduto(termo: string): Observable<Produto[]> {
    const url = `${this.apiUrl}/nome/${termo}`;
    return this.http.get<Produto[]>(url)
                 .pipe(retry(10)
                        , map((resposta: any) => resposta));
  }

  public pesquisarPorCategoria(id: number): Observable<Produto[]> {
    const url = `${this.apiUrl}/categoria/${id}`;
    return this.http.get<Produto[]>(url).pipe(
            delay(2000),
            catchError(this.handleError('pesquisarPorCategoria', []))
        );
  }

}