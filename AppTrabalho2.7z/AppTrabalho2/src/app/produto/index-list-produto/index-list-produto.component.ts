import { Component, OnInit } from '@angular/core';
import{ ProdutoService } from '../produto.service';
import { Produto } from 'src/app/shared/produto.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-index-list-produto',
  templateUrl: './index-list-produto.component.html',
  styleUrls: ['./index-list-produto.component.css']
})
export class IndexListProdutoComponent implements OnInit {

   public produtos: Observable<Produto[]>;

  constructor(private produtoService: ProdutoService) { }

  ngOnInit() {
    this.produtos = this.produtoService.getProdutos();
  }

  public deletarProduto(id: number): void{
    this.produtoService.deletarProduto(id).subscribe();
  }
}
