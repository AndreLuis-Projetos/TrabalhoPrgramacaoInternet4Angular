import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndexListProdutoComponent } from './index-list-produto.component';

describe('IndexListProdutoComponent', () => {
  let component: IndexListProdutoComponent;
  let fixture: ComponentFixture<IndexListProdutoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndexListProdutoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndexListProdutoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
