import { Injectable } from '@angular/core';
import { Categoria } from '../shared/categoria.model';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, delay } from 'rxjs/operators';
import { HttpErrorHandlerService, HandleError } from '../http-error-handler.service';

const httpOptions = {
  headers: new HttpHeaders(
    {'Content-Type':  'application/json','Authorization': 'my-auth-token'})
};

@Injectable({
  providedIn: 'root'
})
export class CategoriaService {
  private handleError: HandleError;
  private apiUrl = 'http://localhost:5000/categoria';

  constructor(
       private http: HttpClient,
       httpErrorHandler: HttpErrorHandlerService) {
       this.handleError = httpErrorHandler.createHandleError('HeroesService');
     }

     public addCategoriaPost(categoria: Categoria): Observable<Categoria> {

        return this.http.post<Categoria>(this.apiUrl, JSON.stringify(categoria), httpOptions)
          .pipe(
                catchError(this.handleError('addCategoriaPost', categoria))
          );
    }

    public getCategorias(): Observable<Categoria[]> {
      return this.http.get<Categoria[]>(this.apiUrl)
        .pipe(
          delay(200),
          catchError(this.handleError<Categoria[]>('getCategorias', []))
        );
    }

    public deletarCategoria(id: number) {
      const url = `${this.apiUrl}/${id}`;
      return this.http.delete(url, httpOptions)
        .pipe(
          catchError(this.handleError('deletarCategoria'))
        );
    }

    public getCategoriaPorId(id: number): Observable<Categoria> {
      const url = `${this.apiUrl}/${id}`;
      return this.http.get<Categoria>(url).pipe(
        tap(_ => console.log(`fetched getCategoriaPorId id=${id}`)),
        catchError(this.handleError<Categoria>('getCategorias id=${id}'))
      );
   }

    public updateCategoria(id: number,categoria: Categoria): Observable<any> {
      const url = `${this.apiUrl}/${id}`;
      return this.http.put(url, categoria, httpOptions).pipe(
        catchError(this.handleError('updateCategoria'))
      );
    }
}
