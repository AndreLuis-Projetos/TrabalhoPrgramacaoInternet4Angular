import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CategoriaService } from '../categoria.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Categoria } from 'src/app/shared/categoria.model';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  @ViewChild('formulario', {static: false}) public formulario: NgForm;
  public id: number;
  public categoria: Categoria;

  constructor(private categoriaService: CategoriaService,
              private router: Router,
              private rota: ActivatedRoute
            ) { }

  ngOnInit() {

    this.id = this.rota.snapshot.params.id;

    if (this.id) {
      this.categoriaService.getCategoriaPorId(this.id).subscribe(res => {
        this.categoria = res;
        this.formulario.setValue({
          nome: res.nome,
          descricao: res.descricao
        });
      }, err => {
        console.log('error: ' + err);
      }
      );
    }
  }

  public salvar(): void {

    const categoria = new Categoria();
    categoria.nome = this.formulario.value.nome;
    categoria.descricao = this.formulario.value.descricao;

    if (this.id) {
      this.categoriaService.updateCategoria(this.id, categoria).subscribe(
        res => {console.log(this.categoria);
        }, err => {console.error('error' + err); }
        );
    } else {

      this.categoriaService.addCategoriaPost(categoria).subscribe(teste => console.log(teste));
    }

    this.router.navigate(['categoria']);
  }
}

