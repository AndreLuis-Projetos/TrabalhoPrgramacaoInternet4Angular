import { Component, OnInit } from '@angular/core';
import{ CategoriaService } from '../categoria.service';
import { Categoria } from 'src/app/shared/categoria.model';
import { Observable } from 'rxjs';
import { ProdutoService } from 'src/app/produto/produto.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})

export class IndexComponent implements OnInit {

  public categorias : Observable<Categoria[]>;
  
  constructor(private categoriaService: CategoriaService,
              private produtoService: ProdutoService) { }

  ngOnInit() {
    this.categorias = this.categoriaService.getCategorias();
  }

  public deletarCategoria(id: number): void{
 
    //console.log(id);
   // var lachou = false;

     //this.produtoService.pesquisarPorCategoria(id)
       //  .subscribe(data=>console.log('tem produto vinculado'),
         //            error=> console.log('Não tem produto vinculado'));

    this.categoriaService.deletarCategoria(id).subscribe();
   // if(lachou){
     //   console.log('achou');
    //}
  }
}