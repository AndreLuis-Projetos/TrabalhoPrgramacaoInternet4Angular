import { Component, OnInit, ViewChild } from '@angular/core';
import { Pedido } from '../shared/pedido.model';
import { OrdemCompraService } from '../ordem-compra.service';
import { NgForm } from '@angular/forms';
import { ItemCarrinho } from '../shared/ItemCarrinho.model';
import { CarrinhoService } from '../carrinho.service';
import { CepService } from '../cep.service';
import { Produto } from '../shared/produto.model';
import { ProdutoService } from '../produto/produto.service';

@Component({
  selector: 'app-ordem-compra',
  templateUrl: './ordem-compra.component.html',
  styleUrls: ['./ordem-compra.component.css']
})
export class OrdemCompraComponent implements OnInit {

  public idPedidoCompra: number;
  public itensCarrinho: ItemCarrinho[] = [];
  public totalCarrinho: number = 0;

  @ViewChild('formulario', {static: false})  public formulario: NgForm;

  constructor(
     private ordemCompraService: OrdemCompraService,
     private carrinhoService: CarrinhoService,
     private cepService: CepService,
     private produtoService: ProdutoService
    ) { }

  ngOnInit() {
    this.itensCarrinho = this.carrinhoService.exebirItens();
    this.totalCarrinho = this.carrinhoService.totalCarrinhoCompras();
  }

  public confirmarCompra(): void {

    if (this.carrinhoService.exebirItens().length === 0) {
      alert('Voce não selecionou nehum item!');
    } else {

      const pedido: Pedido = new Pedido();
      pedido.numero = this.formulario.value.numero;
      pedido.endereco = this.formulario.value.endereco;
      pedido.formaPagamento = this.formulario.value.formaPagamento;
      pedido.complemento = this.formulario.value.complemento;
      pedido.cep = this.formulario.value.cep;
      pedido.bairro = this.formulario.value.bairro;
      pedido.cidade = this.formulario.value.cidade;
      pedido.uf = this.formulario.value.uf;
      pedido.dataPedido = new Date();
      pedido.itens = this.carrinhoService.exebirItens();
      // tslint:disable-next-line:prefer-for-of
      for ( let i = 0; i < this.itensCarrinho.length; i++) {
        const produto: Produto = new Produto();
        produto._id = this.itensCarrinho[i]._id;
        produto.quantidade = this.itensCarrinho[i].quantidade;
        this.produtoService.updateProdutoQuantidade(this.itensCarrinho[i]._id, produto).subscribe(
          res => {console.log('alterou')
          }, err => {console.error("error"+ err)}
          );
       }
      this.ordemCompraService.efetivarCompra(pedido)
          .subscribe((idPedido: number) => {
                this.idPedidoCompra = idPedido;
                this.carrinhoService.limparCarrinho();
          });
    }
  }

   public adicionarQuantidade(item: ItemCarrinho): void {
      this.carrinhoService.adicionarQuantidade(item);
      this.totalCarrinho = this.carrinhoService.totalCarrinhoCompras();
    }

 public diminuirQuantidade(item: ItemCarrinho): void {
   this.carrinhoService.diminuirQuantidade(item);
   this.totalCarrinho = this.carrinhoService.totalCarrinhoCompras();
 }

 consultaCEP(cep, form) {
  cep = cep.replace(/\D/g, '');

  if (cep !== '' ) {
    const validaCep = /^[0-9]{8}$/;
    if (validaCep.test(cep)) {
      this.cepService.getCep(cep).subscribe(dados => { this.populaDadosForm(dados, form)});
    }
  }
 }

 populaDadosForm(dados, form) {

   form.setValue({
    endereco: dados.logradouro,
    cep: dados.cep,
    numero: '',
    complemento: dados.complemento,
    formaPagamento: form.value.formaPagamento,
    bairro: dados.bairro,
    cidade: dados.localidade,
    uf: dados.uf
   });
 }
// tslint:disable-next-line:eofline
}