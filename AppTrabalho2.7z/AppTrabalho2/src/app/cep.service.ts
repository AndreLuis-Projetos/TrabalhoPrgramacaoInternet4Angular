import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders  } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs-compat/operator/map';

@Injectable({
  providedIn: 'root'
})
export class CepService {

  constructor(private http: HttpClient) { }

  getCep(cep): Observable<any> {

    return this.http.get('https://viacep.com.br/ws/' + cep + '/json/').map((resposta: Response) => resposta);
  }
}
