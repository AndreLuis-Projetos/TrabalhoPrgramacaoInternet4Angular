import { Injectable } from '@angular/core';
import { Produto } from './shared/produto.model';
import { ItemCarrinho } from './shared/ItemCarrinho.model';

@Injectable({
  providedIn: 'root'
})
export class CarrinhoService {

  public itens: ItemCarrinho[] = [];
  public totalItemCarrinho: number = 0;

  public exebirItens(): ItemCarrinho[] {
    let localStorageItem = JSON.parse(localStorage.getItem('carrinhoCompra'));
    return  this.itens = localStorageItem = null ? [] : localStorageItem.itens;
  }

  public incluirItem(produto: Produto): void {
      const itemCarrinho: ItemCarrinho = new ItemCarrinho();
      itemCarrinho._id = produto._id;
      itemCarrinho.img = produto.imagens;
      itemCarrinho.titulo = produto.nome;
      itemCarrinho.descricao = produto.descricao;
      itemCarrinho.quantidade = 1;
      itemCarrinho.quantidadeProduto = produto.quantidade;
      itemCarrinho.valor = this.calcularDesconto(produto.preco,produto.desconto);
      itemCarrinho.desconto = produto.desconto;
      itemCarrinho.valorSemDesconto = produto.preco;

      const itemCarrinhoEncontrado = this.itens.find((item: ItemCarrinho) => item._id === itemCarrinho._id);

      if (itemCarrinhoEncontrado) {
         itemCarrinhoEncontrado.quantidade += 1;
      } else {
        this.itens.push(itemCarrinho);
      }

      localStorage.setItem('carrinhoCompra', JSON.stringify({itens: this.itens}));
  }

  public calcularDesconto(preco, desconto): number {
    if (desconto > 0 || desconto != null || desconto !== undefined) {
      const descontoPercente = 10 / 100;
      const descontoCalculado = descontoPercente * preco;
      return preco - descontoCalculado;
    }
    return preco;
  }

  public totalCarrinhoCompras(): number {
    let total = 0;

    this.itens.map((item: ItemCarrinho) => {
         total += (item.valor * item.quantidade);
     });
    return  total;
  }

  public adicionarQuantidade(itemCarrinho: ItemCarrinho): void {
    const itemCarrinhoEncontrado = this.itens.find((item: ItemCarrinho) => item._id === itemCarrinho._id);

    if (itemCarrinhoEncontrado) {
      itemCarrinho.quantidade += 1;

      this.verificaQuantidadeDoCarrinho(itemCarrinho.quantidade, itemCarrinhoEncontrado.quantidadeProduto);
      localStorage.setItem('carrinhoCompra', JSON.stringify({itens: this.itens}));
    }
  }

  private verificaQuantidadeDoCarrinho(quantidadeCarrinho: number, quantidadeBase: number): void {
    if (quantidadeCarrinho > quantidadeBase) {
      alert('A quantidade de item no carrinho, ultrapassa o que temos em estoque.');
    }
  }

  public diminuirQuantidade(itemCarrinho: ItemCarrinho): void {
    const itemCarrinhoEncontrado = this.itens.find((item: ItemCarrinho) => item._id === itemCarrinho._id);

    if (itemCarrinhoEncontrado) {
      itemCarrinho.quantidade -= 1;

      if (itemCarrinho.quantidade === 0) {
          this.itens.splice(this.itens.indexOf(itemCarrinhoEncontrado), 1);
      }
      localStorage.setItem('carrinhoCompra', JSON.stringify({itens: this.itens}));
    }
  }

  public calcularTotalCarrinhoCompras(): void {

    let total = 0;

    this.itens.map((item: ItemCarrinho) => {
        total += (item.valor * item.quantidade);
    });

    this.totalItemCarrinho = total;
  }

  public limparCarrinho(): void {
    this.itens = [];
    localStorage.setItem('carrinhoCompra', JSON.stringify({itens: this.itens}));
  }

  public quantidadeItens(): number {
    return this.itens.length;
  }

  constructor() { }
}
