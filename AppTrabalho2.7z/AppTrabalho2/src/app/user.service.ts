import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from './shared/user';

@Injectable({ providedIn: 'root' })
export class UserService {
    constructor(private http: HttpClient) { }

    private apiUsuario = 'http://localhost:5000/usuario';

    getAll() {
        return this.http.get<User[]>(this.apiUsuario);
    }

    getById(id: number) {
        return this.http.get(`${this.apiUsuario}/${id}`);
    }

    register(user: User) {
        return this.http.post(this.apiUsuario, user);
    }

    update(user: User) {
        return this.http.put(`${this.apiUsuario}/${user._id}`, user);
    }

    delete(id: number) {
        return this.http.delete(`${this.apiUsuario}/${id}`);
    }
// tslint:disable-next-line:eofline
}