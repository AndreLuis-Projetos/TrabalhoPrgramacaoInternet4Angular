import { Categoria} from './categoria.model';

export class Produto {
    // tslint:disable-next-line:variable-name
    public _id: number;
    public nome: string;
    public descricao: string;
    public preco: number;
    public quantidade: number;
    public dataValidade: Date;
    public marca: string;
    public unidade: string;
    public peso: number;
    public imagens: string;
    public categoria: Categoria;
    public desconto: number;
}
