import { ItemCarrinho } from './ItemCarrinho.model';

export class Pedido {
    // tslint:disable-next-line:variable-name
    public _id: number;
    public endereco: string;
    public numero: string;
    public complemento: string;
    public formaPagamento: string;
    public itens: Array<ItemCarrinho>;
    public cep: string;
    public bairro: string;
    public cidade: string;
    public uf: string;
    public dataPedido: Date;
}
