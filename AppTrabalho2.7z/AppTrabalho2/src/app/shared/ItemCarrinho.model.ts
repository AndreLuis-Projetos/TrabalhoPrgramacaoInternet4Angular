export class ItemCarrinho {
    // tslint:disable-next-line:variable-name
    public _id: number;
    public img: string;
    public titulo: string;
    public descricao: string;
    public quantidade: number;
    public quantidadeProduto: number;
    public valor: number;
    public desconto: number;
    public valorSemDesconto: number;
}
