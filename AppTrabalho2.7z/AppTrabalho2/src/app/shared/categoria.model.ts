export class Categoria {
    // tslint:disable-next-line:variable-name
    public _id: number;
    public nome: string;
    public descricao: string;
}
