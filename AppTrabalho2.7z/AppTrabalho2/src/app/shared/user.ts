export class User {
    // tslint:disable-next-line:variable-name
    _id: number;
    username: string;
    password: string;
    firstName: string;
    lastName: string;
    token: string;
}
