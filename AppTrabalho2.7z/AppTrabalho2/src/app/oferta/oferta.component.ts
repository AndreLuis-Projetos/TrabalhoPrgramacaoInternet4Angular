import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ProdutoService } from '../produto/produto.service';
import { Produto } from '../shared/produto.model';
import { CarrinhoService } from '../carrinho.service';

@Component({
  selector: 'app-oferta',
  templateUrl: './oferta.component.html',
  styleUrls: ['./oferta.component.css']
})
export class OfertaComponent implements OnInit {

  public produto: Produto;

  constructor( 
     private route: ActivatedRoute, 
     private produtoService: ProdutoService,
     private router: Router,
     private carrinhoService: CarrinhoService 
     ) { }

  ngOnInit() {
    this.route.params.subscribe((parametros: Params) =>
      { 
        this.produtoService.produtoPorId(parametros.id).subscribe(produto=>{ this.produto = produto});    
        });        
  }

  public adicionarItemCarrinho(): void{
      this.carrinhoService.incluirItem(this.produto);
      this.router.navigate(['home']);
  }

}
