import { Injectable } from '@angular/core';
import { Pedido } from './shared/pedido.model';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class OrdemCompraService {

  private URL_API = 'http://localhost:5000';

  constructor(private http: HttpClient) { }

  public efetivarCompra(pedido: Pedido): Observable<any> {
     return this.http.post(`${this.URL_API}/pedido`, JSON.stringify(pedido), httpOptions).map((resposta: Response) => resposta['_id']);
  }
}
