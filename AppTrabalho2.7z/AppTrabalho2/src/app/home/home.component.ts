import { Component, OnInit } from '@angular/core';
import { ProdutoService } from '../produto/produto.service';
import { Produto } from '../shared/produto.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public produtos: Observable<Produto[]>;

  constructor(private produtoService: ProdutoService) {}

  ngOnInit() {
      this.produtos = this.produtoService.getProdutos();
  }
}
