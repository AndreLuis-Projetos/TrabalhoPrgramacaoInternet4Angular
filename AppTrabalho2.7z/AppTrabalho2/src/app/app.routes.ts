import { Routes} from '@angular/router';
import { CreateComponent } from './categoria/create/create.component';
import { IndexComponent } from './categoria/index/index.component';
import { IndexListProdutoComponent } from './produto/index-list-produto/index-list-produto.component';
import { HomeComponent } from './home/home.component';
import { OfertaComponent } from './oferta/oferta.component';
import { OrdemCompraComponent } from './ordem-compra/ordem-compra.component';
import { CreateProdutoComponent } from './produto/create-produto/create-produto.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AuthGuard } from './_guards/auth.guard';
import { UsuarioComponent } from './usuario/usuario.component';

export const appRoutes: Routes = [
    { path: '', component: HomeComponent, canActivate: [AuthGuard] },
    {path: 'home', component: HomeComponent, canActivate: [AuthGuard] },
    {path: 'home/:id', component: HomeComponent},
    {path: 'usuario', component: UsuarioComponent, canActivate: [AuthGuard]},
    {path: 'categoria/create', component: CreateComponent},
    {path: 'categoria/edit/:id', component: CreateComponent},
    {path: 'categoria', component: IndexComponent, canActivate: [AuthGuard] },
    {path: 'produto', component: IndexListProdutoComponent, canActivate: [AuthGuard] },
    {path: 'produto/create', component: CreateProdutoComponent},
    {path: 'produto/edit/:id', component: CreateProdutoComponent},
    { path: 'oferta', component: HomeComponent, canActivate: [AuthGuard] },
    { path: 'oferta/:id', component: OfertaComponent},
    { path: 'ordem-compra', component: OrdemCompraComponent , canActivate: [AuthGuard]},
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
    { path: '**', redirectTo: '' }
];
