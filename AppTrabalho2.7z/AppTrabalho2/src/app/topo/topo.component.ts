import { Component, OnInit, Input } from '@angular/core';
import { Subject, Observable, observable } from 'rxjs';
import { Produto } from '../shared/produto.model';
import { ProdutoService } from '../produto/produto.service';
import { debounceTime } from 'rxjs/operators/debounceTime';
import { switchMap } from 'rxjs/operators/switchMap';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import { Categoria } from '../shared/categoria.model';
import { CategoriaService } from '../categoria/categoria.service';
import { CarrinhoService } from '../carrinho.service';
import { catchError, distinctUntilChanged } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { User } from '../shared/user';

@Component({
  selector: 'app-topo',
  templateUrl: './topo.component.html',
  styleUrls: ['./topo.component.css']
})
export class TopoComponent implements OnInit {
  public produtos: Observable<Produto[]>;
  private subjectPesquisa: Subject<string> = new Subject<string>();
  public categorias: Observable<Categoria[]>;
  public quantidadeItens: number;
  currentUser: User;

  constructor(private produtoService: ProdutoService,
              private categoriaService: CategoriaService,
              private carrinhoService: CarrinhoService,
              private router: Router,
              private authenticationService: AuthenticationService ) {
                this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
               }

  ngOnInit() {
    this.produtos = this.subjectPesquisa
    .pipe(debounceTime(1000))
    .pipe(distinctUntilChanged())
    .pipe(switchMap((termoDaBusca: string) => {
         if( termoDaBusca.trim() === '') {
           return Observable.of<Produto[]>([])
         }
         return this.produtoService.pesquisarPorProduto(termoDaBusca);
      })
    ).pipe(catchError((err: any) => {
      //console.log('Erro: ', catchError);
      return Observable.of<Produto[]>([]);
    }));

    this.categorias = this.categoriaService.getCategorias();
    this.carrinhoService.exebirItens();
    this.quantidadeItens = this.carrinhoService.quantidadeItens();
  }

  public pesquisa(temoDaBusca: string): void {
    this.subjectPesquisa.next(temoDaBusca);
  }

  public limpaPesquisa(): void {
    this.subjectPesquisa.next('');
  }

  logout() {
    this.authenticationService.logout();
    this.router.navigate(['/login']);
}

}
